import 'package:flutter/material.dart';

class MovieListWidget extends StatelessWidget {
  const MovieListWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return ListView.builder(
      // padding: EdgeInsets.symmetric(vertical: 20, horizontal: 10),
      itemCount: 10,
      itemExtent: 163,
      padding: EdgeInsets.symmetric(vertical: 16, horizontal: 16),

      itemBuilder: (context, index) {
        return Container(
          margin: EdgeInsets.symmetric(vertical: 10),
          decoration: BoxDecoration(
            // shape: BoxShape.rectangle,
            borderRadius: BorderRadius.circular(10),
            border: Border.all(color: Colors.grey.withOpacity(0.1), width: 1),
            color: Colors.white,
            boxShadow: [
              BoxShadow(
                  offset: Offset(4, 4),
                  color: Colors.grey.withOpacity(0.2),
                  blurRadius: 4)
            ],
          ),
          child: CardFilmsWidget(),
        );
      },
    );
  }
}

class CardFilmsWidget extends StatelessWidget {
  const CardFilmsWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Row(
      children: [
        ClipRRect(
          child: Image.asset('images/posters/spider-man.jpg'),
          borderRadius: BorderRadius.only(
              topLeft: Radius.circular(10), bottomLeft: Radius.circular(10)),
        ),
        DescriptionsFilmsWidget()
      ],
    );
  }
}

class DescriptionsFilmsWidget extends StatelessWidget {
  const DescriptionsFilmsWidget({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      padding: EdgeInsets.symmetric(vertical: 10, horizontal: 20),
      child: Expanded(
        // ignore: prefer_const_literals_to_create_immutables
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          // Text('Нет пути домой',
          //     style: TextStyle(fontSize: 18, fontWeight: FontWeight.bold)),
          // Padding(padding: EdgeInsets.symmetric(vertical: 5)),
          // Text(
          //   '15 декабря 2021',
          //   style: TextStyle(
          //       fontSize: 14, fontWeight: FontWeight.w200, color: Colors.grey),
          // ),
          // Padding(padding: EdgeInsets.symmetric(vertical: 10)),
          // fit: FlexFit.tight,

          Text(
            'Действие фильма «Человек-паук: Нет пути домой» начинает своё развитие в тот момент, когда Мистерио удаётся выяснить истинную личность Человека-паука. С этого момента жизнь Питера Паркера становится невыносимой. Если ранее он мог успешно переключаться между своими амплуа, то сейчас это сделать невозможно. Переворачивается с ног на голову не только жизнь Человека-пауку, но и репутация. Понимая, ',
            // overflow: TextOverflow.ellipsis,
            // softWrap: true,
            // maxLines: 2,
          ),
        ]),
      ),
    );
  }
}
