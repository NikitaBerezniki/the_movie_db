import 'package:flutter/material.dart';

import 'package:the_movie_db/show_image.dart';
import 'authorization_tmdb.dart';
import 'package:the_movie_db/movie_list.dart';

abstract class AppColor {
  static const Color backgroundColor = Color.fromRGBO(3, 37, 65, 1);
  static const Color whiteColor = Colors.white;
  static const Color blueAccentColor = Colors.blueAccent;
}

abstract class AppTextStyle {
  static const TextStyle drawerHeaderTextStyle =
      TextStyle(color: AppColor.whiteColor, fontSize: 24);
  static const TextStyle drawerTextStyle =
      TextStyle(color: AppColor.whiteColor, fontSize: 18);
}

void main() {
  runApp(MaterialApp(
    title: 'The Movie DB',
    debugShowCheckedModeBanner: false,
    theme: ThemeData(
        // primarySwatch: Colors.blue,
        ),
    initialRoute: '/test',
    routes: {
      '/': (context) => MainPages(),
      '/test': (context) => TestWidget(),
    },
  ));
}

class TestWidget extends StatelessWidget {
  const TestWidget({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
        body: Container(
      padding: EdgeInsets.all(10),
      child: Wrap(
        direction: Axis.horizontal,
        children: [
          ClipRRect(
            child: Image.asset('images/posters/enkanto.jpg'),
            borderRadius: BorderRadius.circular(30),
          ),
          Padding(padding: EdgeInsets.all(20)),
          Text(
            'Действие фильма «Человек-паук: Нет пути домой» начинает своё развитие в тот момент, когда Мистерио удаётся выяснить истинную личность Человека-паука. С этого момента жизнь Питера Паркера становится невыносимой. Если ранее он мог успешно переключаться между своими амплуа, то сейчас это сделать невозможно. Переворачивается с ног на голову не только жизнь Человека-пауку, но и репутация. Понимая, ',
          )
        ],
      ),
    ));
  }
}

class MainPages extends StatefulWidget {
  const MainPages({Key? key}) : super(key: key);

  @override
  State<MainPages> createState() => _MainPagesState();
}

class _MainPagesState extends State<MainPages> {
  int _selectedTab = 0;

  static const List<Widget> _widgetOptions = [
    MovieListWidget(),
    Text('Фильмы'),
    Text('Сериалы')
  ];

  void _onSelectTab(int index) {
    if (_selectedTab == index) return;
    setState(() {
      _selectedTab = index;
    });
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      drawer: MyDrawer(),
      appBar: TMDBAppBar(),
      body: SafeArea(
        child: _widgetOptions[_selectedTab],
      ),
      bottomNavigationBar: BottomNavigationBar(
        showSelectedLabels: false,
        showUnselectedLabels: false,
        iconSize: 24,
        onTap: _onSelectTab,
        currentIndex: _selectedTab,
        selectedItemColor: AppColor.whiteColor,
        unselectedItemColor: AppColor.blueAccentColor,
        backgroundColor: AppColor.backgroundColor,
        items: const [
          BottomNavigationBarItem(
              icon: Icon(Icons.newspaper), label: 'Новости'),
          BottomNavigationBarItem(icon: Icon(Icons.camera), label: 'Фильмы'),
          BottomNavigationBarItem(
              icon: Icon(Icons.file_download), label: 'Сериалы')
        ],
      ),
    );
  }

  AppBar TMDBAppBar() {
    return AppBar(
      backgroundColor: AppColor.backgroundColor,
      title: IconButton(
          tooltip: 'Main page',
          splashRadius: 0.1,
          icon: Image.asset('images/logo.png'),
          iconSize: 50,
          onPressed: () {}),
      centerTitle: true,
      actions: [
        IconButton(icon: Icon(Icons.person), onPressed: () {}),
        SizedBox(width: 10),
        IconButton(
            icon: Icon(Icons.search, color: AppColor.blueAccentColor),
            onPressed: () {}),
        SizedBox(width: 20)
      ],
    );
  }
}

class MyDrawer extends StatefulWidget {
  const MyDrawer({Key? key}) : super(key: key);

  @override
  _MyDrawerState createState() => _MyDrawerState();
}

class _MyDrawerState extends State<MyDrawer> {
  @override
  Widget build(BuildContext context) {
    return Drawer(
      child: Drawer(
        // elevation: 20,
        backgroundColor: AppColor.backgroundColor,
        child: ListView(
          // padding: EdgeInsets.zero,
          children: [
            Padding(padding: EdgeInsets.symmetric(vertical: 10)),
            // DrawerHeader(
            //   child: Text('The Movie DataBase',
            //       style: AppTextStyle.drawerHeaderTextStyle),
            //   decoration: BoxDecoration(
            //       color: AppColor.blueAccentColor,
            //       image: DecorationImage(
            //           fit: BoxFit.fill,
            //           image: AssetImage('assets/img/logo.png'))),
            // ),
            ListTile(
              title: Text('Фильмы', style: AppTextStyle.drawerTextStyle),
              onTap: () {},
            ),
            ListTile(
              title: Text('Сериалы', style: AppTextStyle.drawerTextStyle),
              onTap: () {},
            ),
            ListTile(
              title: Text('Feedback', style: AppTextStyle.drawerTextStyle),
              onTap: () {
                Navigator.of(context).pop();
              },
            ),
          ],
        ),
      ),
    );
  }
}
