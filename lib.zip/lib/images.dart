import 'package:flutter/widgets.dart';

abstract class AppImage {
  static const tree = AssetImage('images/tree.png');
  static const likes = AssetImage('images/Heart 2.png');
}
