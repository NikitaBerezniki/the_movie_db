import 'package:flutter/material.dart';
import 'package:the_movie_db/input_formatters.dart';
import 'main.dart';

class MyExample extends StatelessWidget {
  const MyExample({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return CustomScrollView(
      // ignore: prefer_const_literals_to_create_immutables
      slivers: [
        SliverAppBar(
          pinned: false,
          snap: false,
          floating: true,
          flexibleSpace: FlexibleSpaceBar(
            centerTitle: true,
            background: MyCustomAppBar(),
          ),
        ),
        SliverToBoxAdapter(
          child: Container(
              // child: Text('Scroll to see the SliverAppBar'),
              // padding: EdgeInsets.symmetric(horizontal: 20, vertical: 20),
              ),
        ),
        SliverList(delegate: SliverChildBuilderDelegate(
          (context, index) {
            return Container(
              padding: EdgeInsets.symmetric(horizontal: 20),
              // color: index.isOdd ? Colors.white : Colors.grey,
              height: 50,
              child: Center(
                  child: Card(
                child: ListTile(
                  leading: Icon(Icons.favorite),
                  trailing: Icon(Icons.account_circle),
                  title: Text('index: $index'),
                ),
              )),
            );
          },
        ))
      ],
    );
  }
}

class MyCustomAppBar extends StatelessWidget {
  const MyCustomAppBar({
    Key? key,
  }) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Container(
      color: AppColor.backgroundColor,
      padding: EdgeInsets.symmetric(horizontal: 10),
      child: Row(mainAxisAlignment: MainAxisAlignment.spaceBetween, children: [
        IconButton(
          onPressed: () {
            // Navigator.of(context).push();
          },
          icon: Icon(
            Icons.menu_rounded,
            color: Colors.white,
          ),
          color: Colors.white,
        ),
        IconButton(
          onPressed: null,
          icon: Image.asset('assets/img/logo.png'),
          iconSize: 50,
        ),
        Row(
          children: const [
            IconButton(
              onPressed: null,
              icon: Icon(
                Icons.search,
                color: Colors.white,
              ),
            ),
            IconButton(
              onPressed: null,
              icon: Icon(
                Icons.person,
                color: Colors.white,
              ),
            )
          ],
        )
      ]),
    );
  }
}
